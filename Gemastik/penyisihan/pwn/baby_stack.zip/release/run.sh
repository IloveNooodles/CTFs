#!/bin/bash
#
exec 2>/dev/null
LD_LIBRARY_PATH=${PWD} ./baby_stack
