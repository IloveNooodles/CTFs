#!/bin/bash
cd /home/cataloque/ && ./cataloque