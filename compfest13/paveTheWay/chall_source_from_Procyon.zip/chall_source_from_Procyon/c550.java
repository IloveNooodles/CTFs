// 
// Decompiled by Procyon v0.5.36
// 

class c550
{
    public static void main(final String[] array) throws Exception {
        System.out.print("Paving your way.");
        pave("");
    }
    
    public static void pave(String s) throws Exception {
        s = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s);
        System.out.print(".");
        Thread.sleep(3600000L);
        c146.pave(s);
    }
}
