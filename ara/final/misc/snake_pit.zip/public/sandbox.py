#!/usr/bin/env python
import re
import sys


class Unbuffered(object):
    def __init__(self, stream):
        self.stream = stream

    def write(self, data):
        self.stream.write(data)
        self.stream.flush()

    def writelines(self, datas):
        self.stream.writelines(datas + '\n')
        self.stream.flush()

    def __getattr__(self, attr):
        return getattr(self.stream, attr)


blacklisted_chars = re.escape('\\(~}?>{)&/%`<$|*=#!-@+"\'0123456789;')
blacklisted_words = [
    'unicode', 'name', 'setattr', 'import', 'open', 'enum',
    'char', 'quit', 'getattr', 'locals', 'globals', 'len',
    'exit', 'exec', 'blacklisted_words', 'print', 'builtins',
    'eval', 'blacklisted_chars', 'repr', 'main', 'subclasses', 'file',
    'class', 'mro', 'input', 'compile', 'init', 'doc', 'fork',
    'popen', 'read', 'map', 'dir', 'help', 'error', 'warning',
    'func_globals', 'vars', 'filter', 'debug', 'object', 'next',
    'word', 'base', 'prompt', 'breakpoint', 'class', 'pass',
    'chr', 'ord', 'iter'
]

blacklisted_chars = '[%s]' % (blacklisted_chars)
blacklisted_words = '|'.join('(%s)' % (_) for _ in blacklisted_words)

stdout = Unbuffered(sys.stdout)
stdout.write('''
  _________              __                  ._.___________
 /   _____/ ____ _____  |  | __ ____   ______| |\__    ___/
 \_____  \ /    \\__  \ |  |/ // __ \  \____ \ |  |    |   
/        \   |  \/ __ \|    <\  ___/  |  |_> >|  |    |   
/_______  /___|  (____  /__|_ \\___  > |   __/__  |____|   
        \/     \/     \/     \/    \/  |__|   \/        
''')

stdout.write('>>> ')
prompt = input()

if re.findall(blacklisted_chars, prompt):
    raise Exception('Blacklisted character detected. Go away!')

if re.findall(blacklisted_words, prompt, re.I):
    raise Exception('Blacklisted word detected. Go away!')

try:
    exec(prompt)
except:
    pass
