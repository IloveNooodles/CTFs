#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define MAX_LEN 1024
#define FLAG_LEN 64

void init() {
	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
}

void print_hex(char *buf, int len) {
    for (int i=0; i<len; i++) {
        printf("%02x", (unsigned char)buf[i]);
    }
    printf("\n");
}

void encrypt1(char *destination, int length, char *a, char *b) {
	for (int i = 0; i < length; i++) {
		destination[i] = a[i] ^ b[i];
	}
}

void encrypt2(char *destination, int length, char *c, char *d, int iterations) {
	char key1[length];
	if (iterations <= 1) return;
	else {
		encrypt1(key1, length, destination, c);
		encrypt2(destination, length, d, c, iterations - 1);
	}
}

char menu() {
	char option;
	printf("\nChoose one of the following\n");
	printf("1. Encrypt a message\n");
	printf("2. View encrypted message\n");
	printf("3. Exit\n");
	printf("> ");
	scanf("%c", &option);
	while (getchar() != '\n');
	return option;
}

int main() {
	FILE *file;
	int index, length = -1;
	char buffer[MAX_LEN];
	char key[MAX_LEN];
	char a[MAX_LEN];
	char b[MAX_LEN];
	char c[MAX_LEN];
	
	init();
	srand(time(NULL));
	printf("Welcome to a pwn x cry chall\n");
	printf("even tho the cry part is ezpz\n");
	
	while (1) {
		switch (menu()) {
			case '1':
				printf("Message: ");
				fgets(buffer, MAX_LEN - FLAG_LEN, stdin);
				length = strlen(buffer);
				
				file = fopen("flag.txt", "rb");
				fread(buffer + length, FLAG_LEN, 1, file);
				fclose(file);

				file = fopen("/dev/urandom", "rb");
				fread(a, length + FLAG_LEN, 1, file);
				fread(b, length + FLAG_LEN, 1, file);
				fread(c, length + FLAG_LEN, 1, file);
				fclose(file);
				
				encrypt1(key, length + FLAG_LEN, a, c);
				encrypt2(b, length + FLAG_LEN, a, c, length/4);
				
				encrypt1(buffer, length + FLAG_LEN, buffer, key);
				break;
			case '2':
				if(length == -1) {
				    printf("Encrypt a message first please.\n");
				    break;
				}

				index = 0;
				printf("\nPlease enter the starting index (%d - %d): ", index, length + FLAG_LEN);
				scanf("%d", &index);
				printf("\nReading substring of the encrypted message from index %d.\n", index);
				while (getchar() != '\n');

				if (index > length) { 
				    printf("Index out of bounds.\n");
				    break;
				}

				printf("Here's your encrypted string with the flag:\n");
				print_hex(buffer + index, length + FLAG_LEN - index);
				break;
			case '3':
				printf("Peace.\n");
				exit(0);
			default:
				printf("Bad Hacker.\n");
				break;
		}
	}
}
